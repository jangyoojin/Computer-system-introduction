#include<stdio.h>

void getbuf(){
    int a1 = 0;
    double b = 0;
    char buf[21];

    scanf("%s", buf);
}

int main()
{
    getbuf();
    return 0;
}

